# Debugging, Logging, and Auditing Agentforce Agents

A field guide to finding out what an agent did, why it did it, and whether anything failed:
- **in development:** Agent Script, preview, and local traces;
- **in production:** Data 360 session tracing, the Trust Layer audit trail, and analytics;
- **at the platform level:** Setup Audit Trail and debug logs.

Everything marked **✅ verified** was run against org `afs4019oct` on 2026-10-12, on real data from the
Pronto agents. Items marked **📄 docs** come from Salesforce documentation or Trailhead and were not
exercised here.

---

## 0. The map: where each kind of evidence lives

| Question | Where to look | When |
|---|---|---|
| Does my Agent Script compile? | `sf agent validate authoring-bundle --json` / AFDX: Validate (Problems tab) | Dev |
| Which subagent ran, what did the LLM see, what did each action return? | Local preview traces `.sfdx/agents/<Agent>/sessions/<id>/traces/<planId>.json` | Dev |
| Same, for a session in the org (Builder, Lightning, Messaging, API) | Builder **Trace** tab / **Session Tracing** → Data 360 `ssot__AiAgent*__dlm` DMOs | Dev + Prod |
| Did anything error? | `AiAgentSessionLog_std__dlm` (ERROR rows) and `ssot__AiAgentInteractionStep__dlm.ErrorMessageText` | Prod |
| What exact prompt or response went to or from the LLM? Toxic? Tokens? | Trust Layer audit: `GenAIGatewayRequest__dlm`, `GenAIGeneration__dlm`, `GenAIContentQuality__dlm`, … | Prod |
| Did users like the answers? | `GenAIFeedback__dlm` / Agent Analytics → User Satisfaction | Prod |
| Trends: errors, escalation, deflection, quality | Agentforce Studio → **Observe & Optimize** (Analytics, Sessions & Intents, Alerts) | Prod |
| Did my Apex or Flow action throw? | Debug logs with a trace flag on the **agent user**, plus Flow fault paths / error emails | Dev + Prod |
| Who changed the agent, its perms, or its user? | `SetupAuditTrail`, `BotVersion` status, and the metadata retrieve history | Audit |
| Regression testing | Testing Center / `sf agent test` (`AiEvaluationDefinition`) | CI |

---

## 1. Development time: Agent Script + preview traces

### 1.1 Compile errors
```bash
sf agent validate authoring-bundle --json --api-name Pronto_Customer_Care
```
- Errors are in `message`, with `[Ln X, Col Y]` references; strip the ANSI codes.
- In VS Code, right-click the `.agent` file → **AFDX: Validate this Agent**. Errors appear in the Problems tab.
- Some errors only surface at `preview start`, for example type and target resolution. Always run a
  preview after validating.

### 1.2 Live preview from the CLI ✅ verified
```bash
sf agent preview start --json --use-live-actions --authoring-bundle Pronto_Customer_Care   # -> sessionId
sf agent preview send  --json --authoring-bundle Pronto_Customer_Care --session-id <id> -u "my lasagna was cold"
sf agent preview end   --json --authoring-bundle Pronto_Customer_Care --session-id <id>
```
- `--use-live-actions` runs the real Apex, Flows, and Prompt Templates as `default_agent_user`.
  Without it, the LLM **simulates** action outputs, which hides permission problems and can cause
  false grounding failures.
- To test the *published* agent, use `--api-name` instead of `--authoring-bundle`, and drop `--use-live-actions`.
- `preview start` now accepts `--context-variables Name=Value` / `--context-variables-json`, which
  sets session variables the same way Builder's variable override does. ✅ the flag exists in this CLI.
  Older guidance (including the developing-agentforce skill) says this is impossible; that is out of date.
- **Apex debug logs during preview:** the *interactive* command
  `sf agent preview --authoring-bundle <X> --use-live-actions --apex-debug --output-dir ./debug`
  writes Apex debug logs you can open in the Apex Replay Debugger. This only works in live mode.
  `preview start` does not have `-x`.

### 1.3 Local trace files ✅ verified
```
.sfdx/agents/<Agent>/index.md                     # list of sessions (live vs simulated)
.sfdx/agents/<Agent>/sessions/<sessionId>/
    metadata.json        # planIds[], mockMode ("Live Test" | "Mock")
    transcript.jsonl     # user/agent turns; agent rows carry raw[].planId
    turn-index.json      # turn -> traceFile mapping
    traces/<planId>.json # one execution trace per turn
```
> ⚠️ Real trace shape is `{planId, sessionId, topic, intent, plan: [ {type: ...}, ... ]}`.
> Some published snippets use `.steps[].stepType`; that path does **not** match these files.
> Use `.plan[].type`.

Step types seen across 138 real traces, and what each one tells you:

| `type` | Look at | Tells you |
|---|---|---|
| `UserInputStep` | `.message` | The utterance |
| `SessionInitialStateStep` / `NodeEntryStateStep` | `.data` | Variable state and which subagent is running |
| `VariableUpdateStep` | `.data.variable_updates[]` (`variable_name`, `variable_past_value`, `variable_new_value`, `variable_change_reason`, `directive_context`) | Every `set`, including the compiled `AgentScriptInternal_agent_instructions` |
| `BeforeReasoningStep` / `BeforeReasoningIterationStep` | `.data` | What ran in `before_reasoning` and the deterministic `->` logic |
| `EnabledToolsStep` | `.data` | Which actions the LLM could see (catches `available when` gating) |
| `LLMStep` | `.messages_sent`, `.tools_sent`, `.response_messages`, `.data.agent_name`, `.data.execution_latency`, **`.errors[]`** | The full prompt, the decision, and LLM or gateway failures |
| `UpdateTopicStep` / `TransitionStep` | `.topic`, `.data` | Subagent switches |
| `FunctionStep` | `.function.name/input/output`, `output.__action_execution_status__`, **`.function.errors[]`**, `.executionLatency` | Action input and output, and action failures |
| `PlannerResponseStep` | `.message`, **`.responseType`** (`Inform` / `Failure`), `.isContentSafe`, `.safetyScore` | What the user got, plus the toxicity scores |
| `OutputEvaluationStep` | `.category` (`GROUNDED` / `UNGROUNDED` / `SMALL_TALK`), `.reason` | The grounding check |
| `GuardrailsStep` | `.instructionAdherence`, `.taskResolution` (`HIGH`, `FULLY_RESOLVED`, `PARTIALLY_RESOLVED`, `UNRESOLVED`, `UNCERTAIN` + reason) | Trust Layer quality evaluators |

**Error signatures to grep for:**
- `FunctionStep.function.errors[]`: `{type:"…:api:execution-error", status:500, detail:"…", instance:"urn:trace:plan_tracer_…"}`
- `LLMStep.errors[]`: gateway errors, e.g. `LLM_GATEKEEPER` rate limits
- `PlannerResponseStep.responseType == "Failure"`: the user saw a system or escalation message
- Two consecutive `UNGROUNDED` → "I apologize, but I encountered an unexpected error"

### 1.4 Automated scan: `scripts/agent-debug/scan-preview-traces.sh` ✅ verified
```bash
scripts/agent-debug/scan-preview-traces.sh                          # all agents, all sessions
scripts/agent-debug/scan-preview-traces.sh Pronto_Customer_Care     # one agent
scripts/agent-debug/scan-preview-traces.sh Pronto_Customer_Care <sessionId>
```
It flags `ACTION_ERROR`, `STEP_ERROR`, `RESPONSE_FAILURE`, `UNSAFE`, `UNGROUNDED`, non-passing
`GUARDRAIL` evaluations, and `SLOW` steps over 10 s.

**What it found in this project:** 22 of 138 turns were flagged.
- **Rate limit:** `LLM_GATEKEEPER … exceeded your rate limit {limit=100000 … tokens;minute … org_status:Trial}`.
  - This is the real cause behind "Sorry, something went wrong on my side".
  - The Trial org allows 100k LLM tokens per minute. Rapid-fire test turns hit it.
- **Prompt-template permission failure:** `draft_apology` failed with *"Failed to retrieve the entity ID for the input value for
  Input:Contact. This may be due to missing or mismatched permissions."*
  - The first attempt also received a hallucinated case ID, `"cold-lasagna-case"`.
  - The agent still said *"I'm also processing compensation"*, and grounding marked that GROUNDED.
    **Grounding does not catch silent action failures.** Check `FunctionStep` errors directly.
- **Guardrail evaluators:** many `taskResolution=UNCERTAIN` results ("Content Quality: LLM Gateway call failed").
  These are the same rate-limit symptom, hitting the evaluators.

### 1.5 Built-in CLI: `sf agent trace` ✅ verified
```bash
sf agent trace list --json
sf agent trace read --json -s <sessionId>                              # per-turn summary
sf agent trace read --json -s <sessionId> -f detail -d errors          # also: actions | grounding | routing
sf agent trace read --json -s <sessionId> -f raw -t <turn>
```
> ⚠️ **Tested on this project's sessions:**
> - `-d errors` **listed** the two `draft_apology` failures, but only gave the action name, not the message.
> - `-d errors` returned **nothing** for the session whose turn failed with `LLM_GATEKEEPER`
>   (an `LLMStep.errors[]` entry), and the summary showed `"error": null`.
>
> Use `scan-preview-traces.sh` or the jq below to catch LLM and gateway errors.

### 1.6 Jq one-liners
```bash
T=.sfdx/agents/<Agent>/sessions/<id>/traces/<planId>.json
jq '[.plan[] | select(.type=="TransitionStep") | .data]' $T                    # routing
jq '[.plan[] | select(.type=="EnabledToolsStep") | .data]' $T                  # visible tools
jq '.plan[] | select(.type=="FunctionStep") | .function | {name,input,errors}' $T
jq '.plan[] | select(.type=="LLMStep") | {agent:.data.agent_name, tools:.tools_sent, resp:.response_messages, errors}' $T
jq '.plan[] | select(.type=="OutputEvaluationStep") | {category,reason}' $T
```

---

## 2. Production: Data 360 Session Tracing ✅ verified (queryable via plain SOQL)

**Enable:** Setup → Quick Find "Einstein Generative AI" → **Einstein Audit, Analytics, and Monitoring
Setup**. On that page:
- turn on **Agentforce Session Tracing**;
- turn on **Audit and Feedback** (§3);
- for analytics quality metrics, also turn on **Knowledge/RAG Quality Data and Metrics**.

This needs Data 360, and data collection starts only after it's turned on. 📄 docs. In this org it
was already on.

These DMOs are queryable with `sf data query` (SOQL) in this org. They are also visible in
Data 360 → Data Explorer / Query Editor.

| DMO | Key fields (API names without the `ssot__…__c` wrapper) | Use |
|---|---|---|
| `ssot__AiAgentSession__dlm` | `StartTimestamp`, `EndTimestamp`, `AiAgentChannelType` (Builder, LightningDesktopCopilot, MIDAS, …), `AiAgentSessionEndType`, `RelatedMessagingSessionId`, `RelatedVoiceCallId`, `VariableText`, `PreviousSessionId` | One row per conversation |
| `ssot__AiAgentSessionParticipant__dlm` | `AiAgentApiName`, `AiAgentVersionApiName`, `AiAgentType`, `AiAgentSessionParticipantRole` (AGENT/USER), `ParticipantId` | **Which agent and version** handled the session, and which user |
| `ssot__AiAgentInteraction__dlm` | `AiAgentSessionId`, `AiAgentInteractionType`, `TopicApiName`, `TelemetryTraceId`, `PrevInteractionId` | One row per turn |
| `ssot__AiAgentInteractionStep__dlm` | `AiAgentInteractionId`, `AiAgentInteractionStepType` (`LLM_STEP`, `ACTION_STEP`, `CLASSIFIER_STEP`, `TRUST_GUARDRAILS_STEP`, `VARIABLE_UPDATE_STEP`), `Name`, `InputValueText`, `OutputValueText`, `PreStepVariableText`, `PostStepVariableText`, **`ErrorMessageText`**, `GenAiGatewayRequestId`, `GenerationId` | Step-level trace, the production equivalent of `plan[]` |
| `ssot__AiAgentInteractionMessage__dlm` | `AiAgentInteractionMessageType`, `ContentText`, `MessageSentTimestamp`, `AiAgentSessionParticipantId` | The transcript |
| **`AiAgentSessionLog_std__dlm`** | `LogLevelType` (DEBUG/INFO/WARNING/ERROR/FATAL), `Category` (docs: Tool, LLM, Retrieval, Guardrail, Auth, HTTP, Delegation, Platform, Lifecycle, Performance; this org: `SYSTEM_ERROR`), `Code` (`ACTION_EXECUTION_FAILED`, `LLM_STEP_FAILED`, …), `Description`, **`DetailedDescription`**, `AiAgentSessionId`, `AiAgentInteractionStepId`, `CauseLogId`, `RootCauseLogId` | **The error log.** Start here |
| Also present | `ssot__AiAgentAction__dlm`, `ssot__AiAgentTopic__dlm`, `ssot__AiAgentMoment__dlm`, `ssot__AiAgentTag*__dlm`, `AiAgentGenerativeAiUsage_std__dlm`, `AiAgentSessionAttachment_std__dlm` | Actions and topics, moments, intent tags, usage |

> ⚠️ Step-type values in this org are `LLM_STEP`, `ACTION_STEP`, `CLASSIFIER_STEP`,
> `TRUST_GUARDRAILS_STEP`, and `VARIABLE_UPDATE_STEP`. The DMO reference lists different values
> (`UserInputStep`, `LLMExecutionStep`, `FunctionStep`), so check what your org actually stores.
>
> ⚠️ Empty values are stored as the string **`'NOT_SET'`**, not null. Filter with `!= 'NOT_SET'`.
>
> ⚠️ `ErrorMessageText` is often just `{"message":"Unknown error","source":"span_status"}`. The useful
> text is in `AiAgentSessionLog_std__dlm.DetailedDescription`. For example, it held the full
> `Input:Contact … missing or mismatched permissions` error. For LLM failures, the precise cause
> (the rate limit) appeared **only** in the preview trace, so keep both sources.

**Error queries that worked here:**
```sql
-- Every runtime error in the last 7 days
SELECT LogDateTime__c, Code__c, Category__c, Description__c, DetailedDescription__c,
       AiAgentSessionId__c, AiAgentInteractionStepId__c
FROM AiAgentSessionLog_std__dlm
WHERE LogLevelType__c = 'ERROR' AND LogDateTime__c = LAST_N_DAYS:7
ORDER BY LogDateTime__c DESC

-- Failed steps with their inputs
SELECT ssot__StartTimestamp__c, ssot__AiAgentInteractionStepType__c, ssot__Name__c,
       ssot__ErrorMessageText__c, ssot__InputValueText__c, ssot__AiAgentInteractionId__c
FROM ssot__AiAgentInteractionStep__dlm
WHERE ssot__ErrorMessageText__c != 'NOT_SET'

-- Reconstruct one turn, step by step
SELECT ssot__StartTimestamp__c, ssot__AiAgentInteractionStepType__c, ssot__Name__c,
       ssot__InputValueText__c, ssot__OutputValueText__c, ssot__ErrorMessageText__c
FROM ssot__AiAgentInteractionStep__dlm
WHERE ssot__AiAgentInteractionId__c = '<interactionId>' ORDER BY ssot__StartTimestamp__c

-- Sessions per agent version (did v2 regress?)
SELECT ssot__AiAgentApiName__c, ssot__AiAgentVersionApiName__c, COUNT(Id) n
FROM ssot__AiAgentSessionParticipant__dlm
WHERE ssot__AiAgentSessionParticipantRole__c = 'AGENT'
GROUP BY ssot__AiAgentApiName__c, ssot__AiAgentVersionApiName__c
```
**Join path:** Session ← Participant / Interaction ← Step / Message. A step joins to the gateway audit
through `GenAiGatewayRequestId`, and a log row joins through `AiAgentSessionId` and `AiAgentInteractionStepId`.

**OTel export (Beta):** `GET /services/data/v66.0/einstein/audit/otel/{sessionId}` returns the
session's tracing and audit data, pre-joined, as OpenTelemetry (OTLP) spans. Use it to forward to
Datadog, Splunk, or Grafana.
- One session per call.
- Only sessions from the last 72 hours.
- Requires OAuth through an External Client App.

📄 docs, not exercised here.

**Builder UI:** Agentforce Builder → Preview → **Trace** tab / Interaction Summary. It shows the same
steps with timings, variable values, and error messages, plus an assistant that explains each step.
Session Tracing requires Data 360. 📄 docs

---

## 3. Production: Trust Layer audit trail (Generative AI Audit & Feedback) ✅ verified

This records every LLM call made through the Einstein gateway, including planner calls, prompt
templates, guardrail evaluators, and the Builder assistant.

| DMO | Key fields | Use |
|---|---|---|
| `GenAIGatewayRequest__dlm` | `gatewayRequestId`, `timestamp`, `feature` (`plannerservice`, `PromptTemplateGenerationsInvocable`, `Guardrails and Citations`, `nextGenAuthoring`, …), `model`, `provider`, `prompt`, **`maskedPrompt`**, `promptTemplateDevName`, `promptTemplateVersionNo`, `promptTokens`, `completionTokens`, `totalTokens`, `userId`, `sessionId`, `plannerId`, `botVersionId`, `enablePiiMasking`, `enableInput/OutputSafetyScoring` | **Exact prompt sent, who sent it, which model, how many tokens** |
| `GenAIGatewayResponse__dlm` | `generationRequestId`, `generationResponseId` | Request ↔ response link |
| `GenAIGeneration__dlm` | `generationId`, `responseText`, `maskedResponseText`, `generationResponseId` | Raw LLM output |
| `GenAIContentQuality__dlm` | `isToxicityDetected`, `contentType` (INPUT/OUTPUT), `parent` (→ request) | Toxicity flag per prompt or response |
| `GenAIContentCategory__dlm` | `category`, `value`, `detectorType`, `parent` | Per-category scores (toxicity, hate, PII detector, …) |
| `GenAIFeedback__dlm` / `GenAIFeedbackDetail__dlm` | `feedback` (thumbs), `action` (accept/modify/…), `generationId`, `userId`, `source` | End-user feedback |
| `GenAiGtwyReqModelDiagnostic_std__dlm` | `ErrorText__c`, `ReqStatusId__c`, `ReqLatencyMsNumber__c`, `AiModelName__c`, `AiApplicationFeatureName__c`, `AiGatewayRequestId__c` | Errors and latency for **LLM calls** (empty in this org so far) |
| `AiAgentGenerativeAiUsage_std__dlm` | `PromptInputTokenCount__c`, `PromptCompletionTokenCount__c`, `AiAgentToolName__c`, `GenAiGatewayModelName__c`, `IsBillableIndicator__c`, `UsageQuantity__c` | Token and credit usage per agent tool (1,119 rows here) |
| Also present | `GenAIGatewayRequestTag__dlm`, `GenAIGtwyRequestMetadata__dlm`, `GenAIGtwyRequestLLM__dlm`, `GenAIGtwyObjRecord__dlm` (records used to ground) | Tags, metadata, grounding records |

> This org has **two parallel name sets**. Legacy `GenAI…__dlm` DMOs use camelCase fields
> (`totalTokens__c`); the newer standard `GenAi…_std__dlm` DMOs use `TotalTokenCount__c`,
> `PromptText__c`, and so on. Both are populated: 1,303 requests in each set. The docs describe the `_std__dlm` set:
> - `GenAIGeneration` ≈ `GenAiResponseGeneration_std__dlm`
> - `GenAIContentCategory` ≈ `GenAiContentQualityCategory_std__dlm`
> - `GenAIFeedbackDetail` ≈ `GenAiFeedbackAdditionalInfo_std__dlm`

**Findings in this org (last 7 days):**
- 1,303 gateway requests.
- `plannerservice` + `gpt-4.1` used about 2.1M tokens, the largest cost driver.
- **One** toxicity flag (INPUT). It was on `nextGenAuthoring`, the Builder assistant, not a customer-facing agent.
- No feedback rows yet. Feedback appears only once users click thumbs up or down.

```sql
SELECT timestamp__c, feature__c, contentType__c, parent__c
FROM GenAIContentQuality__dlm WHERE isToxicityDetected__c = 'true'

SELECT feature__c, model__c, COUNT(Id) n, SUM(totalTokens__c) tokens
FROM GenAIGatewayRequest__dlm WHERE timestamp__c = LAST_N_DAYS:7 GROUP BY feature__c, model__c

SELECT timestamp__c, userId__c, promptTemplateDevName__c, maskedPrompt__c
FROM GenAIGatewayRequest__dlm WHERE gatewayRequestId__c = '<id>'
```
**Notes:**
- 📄 Data masking is not applied to agents' planner prompts; it covers embedded gen-AI features and
  prompt templates. This repo's Lesson 3 saw `<CREDIT_CARD_0>` masking in a template.
- These features consume Data 360 credits.

---

## 4. Production dashboards: Agentforce Studio → Observe & Optimize 📄 docs

- **Analytics** (Tableau Next): filter by agent, timeframe, channel, and modality. The dimension tabs are:
  - **Effectiveness:** deflection, escalation, abandonment (2 h timeout), success rate (action steps without
    errors), and task resolution.
  - **Usage:** sessions, interactions, and users.
  - **Quality:** quality score 1–5, answer faithfulness and relevance.
  - **Health:** error rate, durations, and latency.
  - **Trust:** adherence and toxicity.
  - **User Satisfaction:** thumbs up/down.
- **Sessions & Intents:** a per-session list with outcome, intent summary, subagents, actions, quality score,
  a downloadable transcript, and a **Trace** tab.
  - The intent pipeline runs about 4–5 h after a session ends.
  - Clustering runs weekly.
- **Alerts:** threshold alerts on any metric (e.g. error rate ≥ X%), delivered by email or in-app, with
  drill-down to the matching sessions.
- **Testing Center** (Setup → Testing Center, or Studio → Tests):
  - Inputs are CSV or AI-generated test cases: utterance, expected subagent, actions, and response.
  - Results report subagent, action, and response pass %.
  - Limits: 10 runs per 10 h and 1,000 cases per test. Tests consume credits and can change data,
    so run them in a sandbox.
  - From the CLI: `sf agent test create/run/results/list --json` (an `AiEvaluationDefinition`), and
    `sf agent test run-eval` for richer evaluations.
    - `--result-format junit|tap` fits CI.
    - Exit code 1 means test cases hit **execution errors**, not that assertions failed.
    - Per-criterion results are stored in `AiEvalTestCaseCritRslt`. 📄 docs

---

## 5. Platform-level logs

### 5.1 Debug logs for Apex and Flow actions
Actions run as the **agent user**:
- **Service agents** run as `default_agent_user`, here `EinsteinServiceAgent User`.
- **Employee agents** run as the user talking to them.

To capture logs, put the trace flag on *that* user:
```bash
# Find the agent user
sf data query --json -q "SELECT Id, Username FROM User WHERE Profile.Name = 'Einstein Agent User'"
# Setup → Debug Logs → New → Traced Entity = that user (or create a TraceFlag via the Tooling API), then
sf apex list log --json            # logs from all users, including the agent user
sf apex get log --json --log-id <id>
```
`sf apex tail log` puts its trace flag on *your* CLI user, so it misses agent-user executions unless
you set the agent-user flag yourself and pass `--skip-trace-flag`.
- At audit time this org had **no** active trace flag on the agent user (one developer trace flag had
  expired) and **zero** Apex logs. A failing Apex action would leave no Apex-level evidence until you
  add one.
- `WITH USER_MODE` + missing object permissions = **0 rows, no error**. Debug logs and the action's
  `OutputValueText` are the only way to see it.
- **Flow actions:** add fault paths that set an `Error_Message_Output` output. Otherwise the agent only
  sees a generic failure. Flow error emails go to the admin or the flow's last modifier.

### 5.2 Event Monitoring 📄 docs (needs the Event Monitoring / Shield add-on; no log files in this org)
- `EventLogFile` event type **`InvocableAction`** (API 64+) records every action invocation.
- Fields include:
  - `INVOCATION_SOURCE` (Agent Action / Bot / Flow / Prompt Template …), `AGENT_ACTION`
  - `PLANNER_IDENTIFIER`, `BOT_IDENTIFIER`, `BOT_SESSION_IDENTIFIER`, `PROMPT_TEMPLATE`
  - `ACTION_NAME`, `DURATION`
- Pair it with `ApexUnexpectedException`, `FlowExecution`, and `ApexCallout`.

### 5.3 Change auditing ✅ verified
```sql
-- Who changed agent permissions or users? (Display can't be filtered in SOQL; filter client-side)
SELECT CreatedDate, CreatedBy.Username, Action, Section, Display
FROM SetupAuditTrail WHERE CreatedDate = LAST_N_DAYS:7 ORDER BY CreatedDate DESC

-- Which versions exist and which is live?
SELECT BotDefinition.DeveloperName, VersionNumber, Status FROM BotVersion
```
- Example rows in this org:
  - *"Permission set Agentforce Action Access: assigned to user EinsteinServiceAgent User"*
  - *"Created permission set Agentforce Agent Pronto_Customer_Care Permissions"*
- `GenAiPlannerBundle`, `AiAuthoringBundle`, and `GenAiFunction` are **not** SOQL-queryable. Use
  `sf project retrieve start --metadata AiAuthoringBundle:<Name>` and diff it in git.
  Every publish creates a new, permanent BotVersion.

### 5.4 Messaging-channel records (service agents)
- `MessagingSession` has `AgentType`, `EndedByType`, `Status`, `ConversationId`, and message counts.
- Enhanced-channel transcripts use the off-core ConversationEntry schema.
- The Agentforce DMO `ssot__RelatedMessagingSessionId__c` links a session to its MessagingSession.

### 5.5 Agent API error codes (headless / custom-channel agents) 📄 docs
- **HTTP statuses:**
  - `400`: bad agent ID
  - `401`: auth
  - `404`: wrong endpoint or token
  - `423`: one request at a time
  - `500`: setup problem, or the 120 s timeout
- **Streaming:** a `ValidationFailureChunk` event means the response failed validation.
- **Reasoner error codes:**
  - `PLANNER_AGENT_NOT_FOUND`, `PLANNER_INVALID_AGENT_DSL`, `PLANNER_SESSION_NOT_FOUND`
  - `PLANNER_LLM_GATEWAY_{RATE_LIMIT, TIMEOUT, EMPTY_GENERATION, STREAM_ERROR, …}`
  - `RATE_LIMIT_EXCEEDED` (retry after 10 s or more)
- Every error carries `instance: "urn:trace:…"`, the same trace ID format seen in preview traces.

---

## 6. Run the full org audit

```bash
scripts/agent-debug/org-agent-audit.sh 7            # last 7 days, default org
scripts/agent-debug/org-agent-audit.sh 30 myAlias   # other org
```
It reports the following sections:
- Runtime errors and error counts by code
- Failed steps with inputs
- Sessions by agent and version, and by channel and end type
- Action usage
- Toxicity hits
- Token usage by feature and model
- Feedback
- Agent-related Setup Audit Trail entries

---

## 7. Triage playbook

1. **"Sorry, something went wrong" / "unexpected error":**
   1. Check `AiAgentSessionLog_std__dlm` for that session.
   2. If you can reproduce it, open the preview trace for the failing turn. Look at `LLMStep.errors`
      (rate limit or gateway problem) and `FunctionStep.function.errors` (action failure), then check
      for two consecutive `UNGROUNDED` results.
2. **Action "succeeded" but the data is wrong or empty:**
   1. Compare `FunctionStep.function.input` against the expected IDs. This catches hallucinated IDs
      like `cold-lasagna-case`.
   2. Check the agent user's object and field permissions (`USER_MODE`), and enable a debug log on the
      agent user.
3. **Wrong subagent or action never called:**
   - `EnabledToolsStep` shows whether the action was visible; `available when` may be hiding it.
   - `LLMStep.messages_sent` shows the compiled instructions; `response_messages` shows what the LLM chose.
4. **Agent claims it did something it didn't:**
   - Grounding passed, but the `FunctionStep` has errors. Add a post-action check in Agent Script
     (`if @outputs.… ` / status variable) so the response can't claim success.
5. **Permission error on an unrelated action:** the planner validates **all** actions across all
   subagents at startup. Grant the agent user access to every action's class, flow, and template.
6. **Intermittent failures under load (Trial org):** look for `LLM_GATEKEEPER` / `E90000` in traces.
   Space test turns out, or use a non-trial org.
7. **Safety or abuse review:**
   - `GenAIContentQuality__dlm` where `isToxicityDetected__c = 'true'`;
   - `PlannerResponseStep.safetyScore` in traces;
   - Analytics → Trust tab.

---

## Sources
- Trailhead:
  - [Agent Analytics and Monitoring](https://trailhead.salesforce.com/content/learn/modules/agent-analytics-and-monitoring)
  - [Agentforce Testing Tools and Strategies](https://trailhead.salesforce.com/content/learn/modules/agentforce-testing-tools-and-strategies)
  - [Agentforce Agent Testing](https://trailhead.salesforce.com/content/learn/modules/agentforce-agent-testing)
  - [The Einstein Trust Layer](https://trailhead.salesforce.com/content/learn/modules/the-einstein-trust-layer)
  - [Create an Agent Using Pro-Code Tools](https://trailhead.salesforce.com/content/learn/projects/create-an-agent-using-pro-code-tools)
  - [Agent Customization with Apex](https://trailhead.salesforce.com/content/learn/modules/agent-customization-with-apex)
  - [Agent Customization with Flows](https://trailhead.salesforce.com/content/learn/modules/agent-customization-with-flows)
  - [Agent Behavior Evaluation](https://trailhead.salesforce.com/content/learn/modules/agent-behavior-evaluation)
- Salesforce Help:
  - [Set Up Agent Analytics](https://help.salesforce.com/s/articleView?id=ai.generative_ai_agent_analytics_setup.htm)
  - [Session Trace](https://help.salesforce.com/s/articleView?id=ai.generative_ai_session_trace.htm)
  - [Audit & Feedback](https://help.salesforce.com/s/articleView?id=ai.generative_ai_feedback.htm)
  - [Monitor Agent Health](https://help.salesforce.com/s/articleView?id=ai.agent_monitor_health.htm)
  - [Troubleshoot Agents](https://help.salesforce.com/s/articleView?id=ai.copilot_troubleshoot.htm)
- Developer docs (the guide moved to `developer.salesforce.com/docs/ai/agentforce/guide/`):
  - OTel API (`otel-api.html`)
  - Preview (`agent-dx-nga-preview.html`)
  - Agent DX troubleshooting (`agent-dx-troubleshooting.html`)
  - Agent API troubleshooting (`agent-api-troubleshooting.html`)
  - Reasoner error reference (`error-ref-agent-svc-reasoner.html`)
  - DMO reference: `developer.salesforce.com/docs/data/data-cloud-dmo-mapping/guide/c360dm-si-<name>dmo-dmo.html`
- Org schema: `sf sobject describe` on each DMO in `afs4019oct`, 2026-10-12.
