# Agent Spec: Pronto_Customer_Care (bundle `Pronto_Customer_Care_3`)

Status: **IMPLEMENTED v6 (loop-hardened, model-portable)**, validated in live preview on 3 models. **Published as `Pronto_Customer_Care` v2 (Active) on 2026-10-15**; v1 inactive.
Supersedes CHECKPOINT 5-2 (backup: `docs/backup/Pronto_Customer_Care_3.checkpoint-5-2.agent`).
Evidence: Data Cloud session tracing for 2026-10-15 (30 Pronto sessions, 153 turns, 1,049 steps) and
local preview trace `01a13ff8-…`.

---

## 0. Diagnosis: 2026-10-15 infinite reasoning loops

### What the logs show

| Turn (UTC) | Model | LLM calls in ONE turn | Pattern |
|---|---|---|---|
| 11:18:06 `25c69de9` | GPT-6 Luna | **53** (~73 s) | `order_help: remember_customer` ×49, a no-op `@utils.setVariables` |
| 11:15:31 `81e61596` | GPT-6 Luna | **53** | `order_help:back_to_router → agent_router:go_to_order_help` ×21 ping-pong |
| 11:11:25 `df58f447` | GPT-6 Luna | **52** | router ↔ order_help ping-pong + make_it_right bounces |
| 11:58:14 `981ac091` | GPT-6 Luna | **28** + 9 Apex calls | `get_related_cases ↔ remember_case` ×8 (≈180 action credits wasted) |
| 11:56:25 `799b3fff` | GPT-6 Luna | 4 | Verified successfully, then **escalated to a human** by mistake |
| 14:10–14:33 | Claude 5 Sonnet | 5–6 | Same script, no loops |

Healthy turns use 4–6 LLM calls. The platform's loop guardrail did **not** stop the 53-call turns.
The 8 `AiAgentSessionLog` errors break down as follows:
- **6 × `LLM_STEP_FAILED`:** gateway errors while you were trying models in Builder (GPT-5.6 Terra,
  Claude 5.5 Opus, Gemini 3.8 Flash).
- **2 × `ACTION_EXECUTION_FAILED`:** `check_code` was called with `authenticationKey = null`, once
  with the email address passed as the code. The current script already prevents this with
  `available when auth_key != ""`.

### Root causes (all present in the script; GPT-6 and Gemini expose them, Claude hides them)

1. **Nothing ends the turn once the job is done.**
   - After a tool call, the runtime re-resolves the subagent's instructions and calls the LLM again.
   - If the instructions and tool list are unchanged, the model sees the same situation every time.
   - GPT-6 is very tool-eager. The platform prompt also says "you MUST use tools … if a tool fails,
     retry". `@utils.setVariables` returns `{}`, which looks like a failure, so GPT-6 keeps calling it.
   - Claude usually stops and writes text, which is why the bug stayed hidden.
2. **Transition ping-pong on a stale utterance.**
   - Every user message starts at `agent_router`, and every transition re-reasons over the same
     message. Example: a bare code `883737` from a customer who is already verified.
   - The router says "code → verify", `verify_customer` sends a verified customer to `order_help`,
     and `order_help` says "not mine → `back_to_router`".
   - No step in this cycle is deterministic or counted, so it can run forever.
3. **Post-action checks are in `after_reasoning`.**
   - `after_reasoning` only runs if the LLM ends the turn *inside* that subagent. If the LLM picks a
     transition, the check never runs.
   - So after a successful `check_code`, `verify_customer` still showed "ask for the code"
     instructions. GPT-6 then picked `go_to_escalation` and a verified customer got a human.
   - The `compensation_pending → make_it_right` hop has the same weakness.
4. **Instructions mention tools that are hidden or irrelevant.** The 11:18 loop told the model to call
   `get_customer_profile` / `get_related_cases`, but only `remember_customer` was enabled. Models
   then call whatever tool they *do* have.
5. **No "already done" state for data tools.** `get_related_cases` stays enabled with the same
   instructions after it has run, so the model re-lists cases every iteration.
6. **Contradictory router rules.** "giving their email → go_to_order_help" and "gives an email
   address → go_to_verify_customer" conflict.

### Secondary findings

- **Security:** `send_code` declares `verificationCode` with `filter_from_agent: True`, but the
  traces show the **code in the LLM's message history** (`"verificationCode":"057953"`). The flag hides
  it from display, not from the model. A user could talk the agent into revealing the code and skip
  email verification.
  - Fix in script: stop mapping the output and add an explicit "never reveal codes" rule.
  - Real fix: remove the output from the `Send_Email_with_Verification_Code` flow.
- **Wasted call:** a full router LLM call runs on every user turn, including "yes" to an offer and
  typed codes. Both cases can be routed deterministically.
- **Unused input:** `issue_gift_certificate` never passes the case. The Apex already accepts `caseId`.
- **Escalation config:** `@utils.escalate` is used without a `connection messaging:` block. It works in
  preview, but it needs an Omni-Channel route to transfer in a real messaging deployment
  (**open question for you**).

---

## Purpose & Scope

Customer-facing service agent for Pronto (food delivery, Dallas). It does three things:
- verifies the customer by email one-time code;
- lists and opens support cases;
- issues one goodwill gift certificate (max $20) per conversation.

## Behavioral Intent

- Nothing about orders, cases, or credits happens before email-code verification. This is enforced
  deterministically (`before_reasoning` + `available when`).
- Backing logic:
  - Flows: `Send_Email_with_Verification_Code`, `Verify_Code`.
  - Apex: `AgentCustomerActions`, `AgentCaseActions`, `AgentCaseCreateActions`,
    `AgentGiftCertificateActions`. All **EXISTS**.
- **Model-portable design rules** (each one fixes a failure seen in the 2026-10-15 logs):
  1. **No path back to the router.** Every customer message starts at `agent_router`, so spokes don't
     need `back_to_router`. Removing it removes the ping-pong, and lets the router's
     `before_reasoning` safely reset per-turn state.
  2. **Every state-driven hop is deterministic** (`transition to` at the TOP of `instructions: ->`, or in
     `before_reasoning`), never in `after_reasoning`, which is skipped if the LLM transitions.
  3. **Every tool is visible only in the state where it applies.** Instructions only mention tools
     visible in the same state.
  4. **Every "one-shot" action has a done-flag** (`profile_loaded`, `cases_loaded`, `issue_attempted`,
     `verify_step_done`, `offer_presented`).
  5. **Per-turn budget:** `turn_steps` counts LLM reasoning steps. Above 6, every tool except
     `@utils.escalate` disappears and the model must answer in text.

## Subagent Map

```mermaid
%%{init: {'theme':'neutral'}}%%
graph TD
    A[start_agent<br/>agent_router<br/>before: reset turn_steps, verify_step_done, just_verified]
    A -->|DETERMINISTIC: auth_key set AND NOT verified AND attempts < 3| C
    A -->|orders / cases / code from verified customer| B[order_help<br/>Subagent]
    A -->|compensation or reply to an offer| D[make_it_right<br/>Subagent]
    A -->|NOT verified: email or code| C[verify_customer<br/>Subagent]
    A -->|wants human| E[escalation<br/>Subagent]
    A -->|unrelated| F[off_topic<br/>Subagent<br/>no tools]

    B -->|before: NOT verified| C
    D -->|before: NOT verified, set compensation_pending| C
    D -->|before: case_id empty, set compensation_pending| B

    C -->|TOP: verified, set customer_id + just_verified| B
    C -->|TOP: NOT verified AND attempts >= 3| E
    C --> C1[send_code<br/>Flow<br/>available when NOT verified AND NOT verify_step_done]
    C --> C2[check_code<br/>Flow<br/>available when auth_key set AND attempts < 3 AND NOT verify_step_done]
    C -->|go_to_escalation<br/>only if NOT verify_step_done| E

    B -->|TOP: compensation_pending AND case_id set| D
    B --> B0[run get_customer_profile ONCE<br/>Apex]
    B --> B1[get_related_cases<br/>Apex<br/>available when NOT cases_loaded]
    B --> B2[create_case<br/>Apex<br/>resets cases_loaded]
    B --> B3[remember_case<br/>setVariables<br/>available when NOT credit_issued]
    B -->|go_to_make_it_right<br/>case_id set AND NOT credit_issued| D

    D --> D1[record_acceptance<br/>setVariables: offer_accepted + offer_amount<br/>available when offer_presented]
    D -->|TOP: accepted AND NOT issue_attempted AND amount >= 10<br/>amount capped at 20| D2[run issue_gift_certificate ONCE<br/>Apex + caseId]
    D -->|go_to_order_help| B
    D -->|go_to_escalation only if issuing failed| E

    E --> E1[escalate_to_human<br/>never budget-gated]
    E -->|only if verified| B
```

All LLM-chosen tools except `escalate_to_human` also carry `available when @variables.turn_steps <= 6`.

## Variables

Existing variables are kept. New:

- **`turn_steps`** (number = 0): LLM reasoning steps used in this turn.
  - Reset in `agent_router.before_reasoning`.
  - +1 in each subagent's instructions, *after* its deterministic transitions, so it counts only steps
    where the LLM runs.
  - Gates every LLM tool at `<= 6`. Above 6 the prompt says "reply now in text".
- **`verify_step_done`** (boolean): one `send_code` or `check_code` per customer message. It also hides
  `go_to_escalation` in a turn where a code was checked, because that message was a code, not a request
  for a human. Reset per turn by the router.
- **`just_verified`** (boolean): set when verification succeeds, so `order_help` continues the original
  request instead of treating the code as a new message. Reset per turn by the router.
- **`profile_loaded`** (boolean): `get_customer_profile` runs once per conversation.
- **`cases_loaded`** (boolean): set from `get_related_cases.success`, reset by `create_case`.
- **`offer_presented`** (boolean): set in `make_it_right.after_reasoning`, which only runs when a
  make_it_right turn *ended* with an offer. `record_acceptance` needs it, so a "yes" to an unrelated
  question can never issue a credit.
- **`offer_amount`** (number): the amount the customer accepted. Capped at 20 deterministically, and the
  certificate is only issued if it is ≥ 10.
- **`issue_attempted`** (boolean): the gift certificate Apex runs at most once, even if it fails.

## Actions & Backing Logic

All targets **EXIST**. Contract changes from CHECKPOINT 5-2:

- **`send_code`:** `verificationCode` is no longer mapped. ⚠️ The flow still returns it, and it still
  reaches the LLM context (seen in the traces). Remove the output from the flow itself.
- **`check_code`:** `customerCode` description is now "digits exactly as typed".
- **`get_related_cases`:** `set cases_loaded = @outputs.success`.
- **`create_case`:** `set cases_loaded = False`.
- **`issue_gift_certificate`:** now `run` deterministically. New `caseId` input links the certificate to
  the case. `giftValue` is bound from `@variables.offer_amount`; the number binds to
  `lightning__numberType` fine.

## Gating Logic

| Action | `available when` (plus `turn_steps <= 6`) | Why |
|---|---|---|
| `go_to_verify_customer` (router) | `is_verified == False` | A verified customer never re-enters verification |
| `send_code` | `is_verified == False and verify_step_done == False` | One send per message |
| `check_code` | `auth_key != "" and code_attempts < 3 and verify_step_done == False` | No check before send; one check per message |
| `verify_customer.go_to_escalation` | `verify_step_done == False` | GPT-6 escalated after a wrong code |
| `get_related_cases` | `is_verified and cases_loaded == False` | GPT-6 re-listed 8× in one turn |
| `create_case` | `is_verified` | |
| `remember_case` | `is_verified and credit_issued == False` | GPT-6 called it 49× / 3× in one turn |
| `order_help.go_to_make_it_right` | `case_id != "" and credit_issued == False` | Removes the order_help ↔ make_it_right bounce |
| `record_acceptance` | `offer_presented and credit_issued == False and issue_attempted == False` | GPT-6 issued a credit before any offer |
| `make_it_right.go_to_escalation` | `issue_attempted and credit_issued == False` | GPT-6 escalated on "another credit?" |
| `escalation.go_to_order_help` | `is_verified == True` | Removes the verify → escalation → order_help → verify cycle |
| `escalate_to_human` | always | A human is always reachable |

## Architecture Pattern

Hub-and-spoke without a return edge to the hub, plus a verification gate and post-action loops. The
router routes deterministically while a code is being entered, and uses the LLM otherwise. Spokes only
link to the specific sibling they need.

## Model Configuration

- Default: `model://sfdc_ai__DefaultBedrockAnthropicClaude5Sonnet`.
- Alternatives validated with the identical script: `sfdc_ai__DefaultGPT6Luna` and
  `sfdc_ai__DefaultVertexAIGemini38Flash`.
- A published version uses one model. To switch, change the one `model:` line, then validate, preview,
  and publish.

## Test Results: 2026-10-15, live preview (`--use-live-actions`), final script

Three conversations per model:
- **Full (10 messages):** greeting → compensation + email → code → details → yes → second credit →
  re-sent code → "what was the code" → off-topic → show cases.
- **Wrong codes (4 messages):** three wrong codes → automatic escalation.
- **Case select (5 messages):** list cases → pick one → yes → human.

| Model | Max LLM calls / turn | Repeated tool calls | Action errors | Wrong escalations | Credits without an offer |
|---|---|---|---|---|---|
| Claude 5 Sonnet | 4 | 0 | 0 | 0 | 0 |
| GPT-6 Luna | 5 | 0 | 0 | 0 | 0 |
| Gemini 3.8 Flash | 5 | 0 | 0 | 0 | 0 |
| *Before (logs, GPT-6 Luna)* | *53* | *49× same tool* | *2* | *1* | — |

Typical calls per turn after the change:
- greeting: 1
- send code: 3
- code → verified → continue the request: 2–5 (was 5–6 plus a router call)
- accept offer: 3 (was 4)
- off-topic: 2

**Known residuals:**
- On follow-ups (second credit, "what was the code") the router sometimes answers in text itself
  instead of routing. Answers were correct and cost 1 call.
- The verification code still reaches the LLM context through the flow output (see Actions).
- `@utils.escalate` has no `connection messaging:` route, so a real messaging deployment won't
  transfer yet (open item).

**Test data created in `afs40112oct`:**
- Gift_Certificate__c 00000003–00000013. 00000006 is from the pre-fix bug run.
- Case 00001016.

## Agent Configuration

- **developer_name:** `Pronto_Customer_Care` (bundle `Pronto_Customer_Care_3`), `AgentforceServiceAgent`.
- **default_agent_user:** `pronto_customer_care@00dbm000013yesj2130985200.ext` (unchanged).
- Published from the unsuffixed bundle `aiAuthoringBundles/Pronto_Customer_Care/`, which is the editable copy from now on. `Pronto_Customer_Care_3/` is an older draft snapshot; do not edit it.
- `Pronto_Customer_Care` **v2 Active** (2026-10-15), v1 Inactive. Rollback: `sf agent activate --json --api-name Pronto_Customer_Care --version 1`.
- Known open items accepted at publish:
  - GPT-6 and Gemini may offer compensation unprompted.
  - GPT-6 can lose an open offer on "can I get more?".
  - The escalation paths still use `@utils.escalate`, and no human handoff is configured.
  - The flow still returns the verification code, kept on purpose for debugging.
